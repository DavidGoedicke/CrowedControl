using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Burst;
using Unity.Collections;
using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Rendering;
using Unity.Transforms;
using Random = Unity.Mathematics.Random;
using UnityEditor;


[UpdateBefore(typeof(AgentSystem))]
public partial class AgentSpawing : SystemBase
{
    struct ComponentDataHandles
    {
        public ComponentLookup<ActiveGate> c_ActiveGateGroup;
        public ComponentLookup<AgentConfiguration> c_agentConfigurationGroup;
        public ComponentLookup<LocalTransform> c_Translate;
        public ComponentLookup<GateSpawnDelay> c_SpawnDelay;

        public ComponentDataHandles(ref SystemState state)
        {
            c_ActiveGateGroup = state.GetComponentLookup<ActiveGate>(true);
            c_agentConfigurationGroup = state.GetComponentLookup<AgentConfiguration>(true);
            c_Translate = state.GetComponentLookup<LocalTransform>(false);

            c_SpawnDelay = state.GetComponentLookup<GateSpawnDelay>(false);
        }

        public void Update(ref SystemState state)
        {
            c_ActiveGateGroup.Update(ref state);
            c_agentConfigurationGroup.Update(ref state);
            c_Translate.Update(ref state);

            c_SpawnDelay.Update(ref state);
        }
    }

    ComponentDataHandles m_Handles;
    private EntityQuery m_WalkingAgents;
    private EntityQuery m_ActiveGatesCount;
    private Random generator;

    protected override void OnCreate()
    {

        Debug.Log("Created Spawning System");
        // Ensure the archetype is initialized once
        if (AgentArchetypeManager.AgentArchetype == null)
        {
            AgentArchetypeManager.InitializeArchetype(EntityManager);
        }



        var builder = new EntityQueryBuilder(Allocator.Temp);
        builder.WithNone<ReadyToSpawn, ArrivedTag>();
        builder.WithAll<WalkingTag, LocalTransform>();
        m_WalkingAgents = GetEntityQuery(builder);

        var builder2 = new EntityQueryBuilder(Allocator.Temp);
        builder2.WithAll<ActiveGate>();
        m_ActiveGatesCount = GetEntityQuery(builder2);

        generator = new Random((uint)DateTime.Now.Second);
        RequireForUpdate<AgentPrefab>();





    }

    protected override void OnDestroy()
    {
    }
    [BurstCompile]
    public partial struct UpdateGateTimeJob : IJobEntity
    {
        public float DeltaTime;

        public void Execute(ref GateSpawnDelay gsDelay)
        {
            gsDelay.Value += DeltaTime;
        }
    }
    [BurstCompile]
    public partial struct FindActiveGatesJob : IJobEntity
    {
        public NativeList<GateNums> AvailableTargets;

        public void Execute(in ActiveGate AG)
        {
            if (!AvailableTargets.Contains(AG.value))
            {
                AvailableTargets.Add(AG.value);
            }
        }
    }
    [BurstCompile]
    public partial struct SpawnAgentJob : IJobEntity
    {
        public EntityCommandBuffer ECB;
        public Entity AgentPrefab;
        public float DeltaTime;
        public NativeArray<GateNums> AvailableTargets;
        public Random Generator;

        public void Execute(ref GateSpawnDelay spawnDelay, in LocalTransform trans, in Entity gateEntity, in ActiveGate gate)
        {
            if (spawnDelay.Value > SimVal.SpawnDelay)
            {
                spawnDelay.Value = 0;

                // Logic to select a target gate
                GateNums targetGate = GateNums.NONE;
                int attempts = 0;
                while (attempts < 100)
                {
                    var tmp = Generator.NextInt(0, AvailableTargets.Length);
                    if (AvailableTargets[tmp] != gate.value)
                    {
                        targetGate = AvailableTargets[tmp];
                        break;
                    }
                    attempts++;
                }

                // Instantiate the agent using the prefab
                var e = ECB.Instantiate(AgentPrefab);

                // Set up custom components for the agent instance
                quaternion q1 = math.mul(trans.Rotation,
                    quaternion.Euler(0, Generator.NextFloat(-math.PI / 4, math.PI / 4), 0));
                float3 tempPos = (math.forward(q1) * 10) + trans.Position + new float3(0, 2, 0);

                ECB.SetComponent(e, new LocalTransform
                {
                    Position = tempPos,
                    Rotation = q1
                });
                ECB.AddComponent( e, new StartGateEntity { Value = gateEntity });
                ECB.AddComponent( e, new AgentConfiguration
                {
                    Speed = 4,
                    TargetGate = targetGate,
                    ViewingDistance = 75,
                    ViewingFilter = AgentAuthoring.ViewingFilter
                });
            }
        }
    }
    protected override void OnUpdate()


    {


        //  m_Handles.Update(ref state);
        float deltaTime = SystemAPI.Time.DeltaTime;
        var job = new UpdateGateTimeJob { DeltaTime = deltaTime };
        Dependency = job.ScheduleParallel(Dependency);

        // Debug.Log("just updated time for the gates respawn");
        int agentCount = m_WalkingAgents.CalculateEntityCount();
        int gateCount = m_ActiveGatesCount.CalculateEntityCount();
        var _agentPrefab = SystemAPI.GetSingleton<AgentPrefab>();
        int targetAgentCount = SimVal.MaxAgents;

        int diff = targetAgentCount - agentCount;

        if (diff <= 0)
        {
            return;
        }

        int spawnPerGate = (int)math.floor(diff / gateCount);
        if (spawnPerGate > 4) spawnPerGate = 4;

        var ecbSingleton = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>();
        var ecb = ecbSingleton.CreateCommandBuffer(World.Unmanaged);

        var availableTargets = new NativeList<GateNums>(Allocator.TempJob);
        var findActiveGatesJob = new FindActiveGatesJob
        {
            AvailableTargets = availableTargets
        };

        Dependency = findActiveGatesJob.Schedule(Dependency);
        Dependency.Complete();

        // Convert NativeList to List if necessary
        List<GateNums> avalibleTargets = availableTargets.ToList();
        availableTargets.Dispose();



        NativeArray<GateNums> _nativeAvalibleTargets =
            new NativeArray<GateNums>(avalibleTargets.ToArray(), Allocator.Temp);

        var spawnJob = new SpawnAgentJob
        {
            ECB = ecb,
            AgentPrefab = _agentPrefab.Value,
            DeltaTime = deltaTime,
            AvailableTargets = _nativeAvalibleTargets,
            Generator = generator
        };
        // Schedule the job
        Dependency = spawnJob.Schedule(Dependency);


    }




    Entity InitAgent(ref EntityCommandBuffer ecb, float3 initialDirection, float4 color)
    {
        // Create an agent entity with all components preset by the archetype
        Entity agent = ecb.CreateEntity(AgentArchetypeManager.AgentArchetype);

        // Set specific values for the agent
        ecb.SetComponent(agent, new WallAvoidVector { Value = float2.zero });
        ecb.SetComponent(agent, new ApplyImpulse { Direction = initialDirection });
        ecb.SetComponent(agent, new URPMaterialPropertyBaseColor { Value = color });

        // Initialize physics components with default values
        ecb.SetComponent(agent, new PhysicsMass
        {
            InverseMass = 1.0f,
            InverseInertia = new float3(1, 1, 1)
        });
        ecb.SetComponent(agent, new PhysicsVelocity
        {
            Linear = float3.zero,
            Angular = float3.zero
        });
        ecb.SetComponent(agent, new PhysicsDamping
        {
            Linear = 0.01f,
            Angular = 0.05f
        });

        return agent;
    }

}